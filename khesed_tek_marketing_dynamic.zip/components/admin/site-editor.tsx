
'use client'

import { useState } from 'react'
import { useSiteConfig } from '@/lib/config'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { ColorPicker } from './color-picker'
import { PlanEditor } from './plan-editor'
import { Save, Palette, Type, CreditCard, Settings, Upload, Eye } from 'lucide-react'

interface SiteEditorProps {
  onClose?: () => void
  onPreview?: () => void
}

export function SiteEditor({ onClose, onPreview }: SiteEditorProps) {
  const { config, updateConfig, loading } = useSiteConfig()
  const [activeTab, setActiveTab] = useState('general')

  const handleSave = () => {
    // In a real app, this would make an API call
    console.log('Saving configuration:', config)
    if (onClose) onClose()
  }

  const handleLogoUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      const reader = new FileReader()
      reader.onload = (e) => {
        const result = e.target?.result as string
        updateConfig({ logo: result })
      }
      reader.readAsDataURL(file)
    }
  }

  const fontOptions = [
    { value: 'Inter', label: 'Inter' },
    { value: 'Roboto', label: 'Roboto' },
    { value: 'Open Sans', label: 'Open Sans' },
    { value: 'Lato', label: 'Lato' },
    { value: 'Montserrat', label: 'Montserrat' },
    { value: 'Poppins', label: 'Poppins' },
    { value: 'Nunito', label: 'Nunito' },
    { value: 'Source Sans Pro', label: 'Source Sans Pro' }
  ]

  return (
    <div className="w-full max-w-4xl mx-auto">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Editor del Sitio Web
              </CardTitle>
              <CardDescription>
                Personaliza la apariencia y contenido de tu sitio web de marketing
              </CardDescription>
            </div>
            <div className="flex gap-2">
              {onPreview && (
                <Button onClick={onPreview} variant="outline">
                  <Eye className="h-4 w-4 mr-2" />
                  Vista Previa
                </Button>
              )}
              <Button onClick={handleSave} disabled={loading}>
                <Save className="h-4 w-4 mr-2" />
                Guardar Cambios
              </Button>
            </div>
          </div>
        </CardHeader>
        
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="general">
                <Settings className="h-4 w-4 mr-2" />
                General
              </TabsTrigger>
              <TabsTrigger value="colors">
                <Palette className="h-4 w-4 mr-2" />
                Colores
              </TabsTrigger>
              <TabsTrigger value="typography">
                <Type className="h-4 w-4 mr-2" />
                Tipografía
              </TabsTrigger>
              <TabsTrigger value="plans">
                <CreditCard className="h-4 w-4 mr-2" />
                Planes
              </TabsTrigger>
            </TabsList>

            {/* General Settings */}
            <TabsContent value="general" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Información General</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Nombre del Sitio</Label>
                      <Input
                        value={config.siteName}
                        onChange={(e) => updateConfig({ siteName: e.target.value })}
                        placeholder="Kḥesed-tek"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Tagline</Label>
                      <Input
                        value={config.tagline}
                        onChange={(e) => updateConfig({ tagline: e.target.value })}
                        placeholder="Church Management Systems"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Descripción</Label>
                    <Textarea
                      value={config.description}
                      onChange={(e) => updateConfig({ description: e.target.value })}
                      placeholder="Descripción del sitio web..."
                      rows={3}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Email de Contacto</Label>
                      <Input
                        value={config.contactEmail}
                        onChange={(e) => updateConfig({ contactEmail: e.target.value })}
                        placeholder="contacto@empresa.com"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Teléfono</Label>
                      <Input
                        value={config.phone}
                        onChange={(e) => updateConfig({ phone: e.target.value })}
                        placeholder="+57 300 123 4567"
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Dirección</Label>
                    <Input
                      value={config.address}
                      onChange={(e) => updateConfig({ address: e.target.value })}
                      placeholder="Ciudad, Departamento, País"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Logo</Label>
                    <div className="flex items-center gap-4">
                      {config.logo && (
                        <div className="w-16 h-16 border rounded-lg overflow-hidden">
                          <img 
                            src={config.logo} 
                            alt="Logo" 
                            className="w-full h-full object-cover"
                          />
                        </div>
                      )}
                      <Button asChild variant="outline">
                        <label className="cursor-pointer">
                          <Upload className="h-4 w-4 mr-2" />
                          Subir Logo
                          <input
                            type="file"
                            accept="image/*"
                            onChange={handleLogoUpload}
                            className="hidden"
                          />
                        </label>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Color Settings */}
            <TabsContent value="colors" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Paleta de Colores</CardTitle>
                  <CardDescription>
                    Personaliza los colores principales de tu sitio web
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <ColorPicker
                      label="Color Primario"
                      color={config.colors.primary}
                      onChange={(color) => updateConfig({ 
                        colors: { ...config.colors, primary: color }
                      })}
                      description="Color principal para botones y enlaces"
                    />
                    
                    <ColorPicker
                      label="Color Secundario"
                      color={config.colors.secondary}
                      onChange={(color) => updateConfig({ 
                        colors: { ...config.colors, secondary: color }
                      })}
                      description="Color secundario para elementos de apoyo"
                    />
                    
                    <ColorPicker
                      label="Color de Acento"
                      color={config.colors.accent}
                      onChange={(color) => updateConfig({ 
                        colors: { ...config.colors, accent: color }
                      })}
                      description="Color para destacar elementos importantes"
                    />
                    
                    <ColorPicker
                      label="Color de Fondo"
                      color={config.colors.background}
                      onChange={(color) => updateConfig({ 
                        colors: { ...config.colors, background: color }
                      })}
                      description="Color de fondo principal del sitio"
                    />
                    
                    <ColorPicker
                      label="Color de Texto"
                      color={config.colors.text}
                      onChange={(color) => updateConfig({ 
                        colors: { ...config.colors, text: color }
                      })}
                      description="Color principal para el texto"
                    />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Typography Settings */}
            <TabsContent value="typography" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Tipografía</CardTitle>
                  <CardDescription>
                    Selecciona las fuentes para títulos y contenido
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Fuente para Títulos</Label>
                      <Select 
                        value={config.fonts.heading} 
                        onValueChange={(value) => updateConfig({ 
                          fonts: { ...config.fonts, heading: value }
                        })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {fontOptions.map((font) => (
                            <SelectItem key={font.value} value={font.value}>
                              <span style={{ fontFamily: font.value }}>{font.label}</span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="space-y-2">
                      <Label>Fuente para Contenido</Label>
                      <Select 
                        value={config.fonts.body} 
                        onValueChange={(value) => updateConfig({ 
                          fonts: { ...config.fonts, body: value }
                        })}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {fontOptions.map((font) => (
                            <SelectItem key={font.value} value={font.value}>
                              <span style={{ fontFamily: font.value }}>{font.label}</span>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="mt-6 p-6 border rounded-lg">
                    <h3 
                      className="text-2xl font-bold mb-2" 
                      style={{ fontFamily: config.fonts.heading }}
                    >
                      Vista Previa de Título
                    </h3>
                    <p 
                      className="text-gray-600" 
                      style={{ fontFamily: config.fonts.body }}
                    >
                      Este es un ejemplo de cómo se verá el contenido con las fuentes seleccionadas. 
                      Puedes cambiar las fuentes usando los selectores de arriba.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Subscription Plans */}
            <TabsContent value="plans" className="space-y-6">
              <PlanEditor
                plans={config.subscriptionPlans}
                onChange={(plans) => updateConfig({ subscriptionPlans: plans })}
              />
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  )
}
