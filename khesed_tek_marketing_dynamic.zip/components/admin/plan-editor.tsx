
'use client'

import { useState } from 'react'
import { SubscriptionPlan } from '@/lib/config'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Plus, Edit, Trash2, DollarSign, Star, Users } from 'lucide-react'
import { formatPrice } from '@/lib/utils'

interface PlanEditorProps {
  plans: SubscriptionPlan[]
  onChange: (plans: SubscriptionPlan[]) => void
}

export function PlanEditor({ plans, onChange }: PlanEditorProps) {
  const [editingPlan, setEditingPlan] = useState<SubscriptionPlan | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [planFeatures, setPlanFeatures] = useState<string[]>([])

  const handleCreatePlan = () => {
    const newPlan: SubscriptionPlan = {
      id: Date.now().toString(),
      name: '',
      displayName: '',
      price: 0,
      period: 'mes',
      description: '',
      maxMembers: '',
      features: [],
      popular: false,
      color: 'from-blue-600 to-blue-700'
    }
    setEditingPlan(newPlan)
    setPlanFeatures([])
    setIsDialogOpen(true)
  }

  const handleEditPlan = (plan: SubscriptionPlan) => {
    setEditingPlan(plan)
    setPlanFeatures([...plan.features])
    setIsDialogOpen(true)
  }

  const handleDeletePlan = (planId: string) => {
    if (confirm('¿Estás seguro de que deseas eliminar este plan?')) {
      onChange(plans.filter(p => p.id !== planId))
    }
  }

  const handleSavePlan = () => {
    if (!editingPlan) return

    const updatedPlan = { ...editingPlan, features: planFeatures }
    
    if (plans.some(p => p.id === editingPlan.id)) {
      // Update existing plan
      onChange(plans.map(p => p.id === editingPlan.id ? updatedPlan : p))
    } else {
      // Add new plan
      onChange([...plans, updatedPlan])
    }

    setIsDialogOpen(false)
    setEditingPlan(null)
    setPlanFeatures([])
  }

  const addFeature = () => {
    setPlanFeatures([...planFeatures, ''])
  }

  const updateFeature = (index: number, value: string) => {
    const updated = [...planFeatures]
    updated[index] = value
    setPlanFeatures(updated)
  }

  const removeFeature = (index: number) => {
    setPlanFeatures(planFeatures.filter((_, i) => i !== index))
  }

  const colorOptions = [
    { value: 'from-blue-600 to-blue-700', label: 'Azul', preview: 'bg-gradient-to-r from-blue-600 to-blue-700' },
    { value: 'from-purple-600 to-purple-700', label: 'Púrpura', preview: 'bg-gradient-to-r from-purple-600 to-purple-700' },
    { value: 'from-green-600 to-green-700', label: 'Verde', preview: 'bg-gradient-to-r from-green-600 to-green-700' },
    { value: 'from-red-600 to-red-700', label: 'Rojo', preview: 'bg-gradient-to-r from-red-600 to-red-700' },
    { value: 'from-yellow-600 to-yellow-700', label: 'Amarillo', preview: 'bg-gradient-to-r from-yellow-600 to-yellow-700' },
    { value: 'from-indigo-600 to-indigo-700', label: 'Índigo', preview: 'bg-gradient-to-r from-indigo-600 to-indigo-700' }
  ]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <DollarSign className="h-5 w-5" />
                Planes de Suscripción
              </CardTitle>
              <CardDescription>
                Gestiona los planes de precios para tu sitio web
              </CardDescription>
            </div>
            <Button onClick={handleCreatePlan}>
              <Plus className="h-4 w-4 mr-2" />
              Nuevo Plan
            </Button>
          </div>
        </CardHeader>
        
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {plans.map((plan) => (
              <Card key={plan.id} className={`relative ${plan.popular ? 'ring-2 ring-blue-500' : ''}`}>
                {plan.popular && (
                  <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                    <div className="bg-blue-500 text-white px-3 py-1 rounded-full text-sm flex items-center">
                      <Star className="h-3 w-3 mr-1" />
                      Popular
                    </div>
                  </div>
                )}
                
                <CardHeader className="text-center">
                  <div className={`w-12 h-12 rounded-full mx-auto mb-4 bg-gradient-to-r ${plan.color} flex items-center justify-center`}>
                    <Users className="h-6 w-6 text-white" />
                  </div>
                  <CardTitle>{plan.displayName || plan.name}</CardTitle>
                  <div className="text-3xl font-bold">
                    ${plan.price}
                    <span className="text-sm text-gray-500">/{plan.period}</span>
                  </div>
                  <p className="text-sm text-gray-600">{plan.maxMembers}</p>
                </CardHeader>
                
                <CardContent>
                  <p className="text-sm text-gray-600 mb-4">{plan.description}</p>
                  
                  <ul className="space-y-2 mb-6">
                    {plan.features.slice(0, 3).map((feature, index) => (
                      <li key={index} className="text-sm flex items-start">
                        <span className="text-green-500 mr-2">✓</span>
                        {feature}
                      </li>
                    ))}
                    {plan.features.length > 3 && (
                      <li className="text-sm text-gray-500">
                        +{plan.features.length - 3} características más
                      </li>
                    )}
                  </ul>
                  
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => handleEditPlan(plan)}
                      variant="outline" 
                      size="sm"
                      className="flex-1"
                    >
                      <Edit className="h-4 w-4 mr-1" />
                      Editar
                    </Button>
                    <Button 
                      onClick={() => handleDeletePlan(plan.id)}
                      variant="outline" 
                      size="sm"
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Edit Plan Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {editingPlan?.id ? 'Editar Plan' : 'Nuevo Plan'}
            </DialogTitle>
            <DialogDescription>
              Configura los detalles del plan de suscripción
            </DialogDescription>
          </DialogHeader>
          
          {editingPlan && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Nombre del Plan</Label>
                  <Input
                    value={editingPlan.name}
                    onChange={(e) => setEditingPlan({ ...editingPlan, name: e.target.value })}
                    placeholder="Básico"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Nombre de Visualización</Label>
                  <Input
                    value={editingPlan.displayName}
                    onChange={(e) => setEditingPlan({ ...editingPlan, displayName: e.target.value })}
                    placeholder="Plan Básico"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div className="space-y-2 col-span-2">
                  <Label>Precio</Label>
                  <Input
                    type="number"
                    value={editingPlan.price}
                    onChange={(e) => setEditingPlan({ ...editingPlan, price: Number(e.target.value) })}
                    placeholder="149"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Período</Label>
                  <Input
                    value={editingPlan.period}
                    onChange={(e) => setEditingPlan({ ...editingPlan, period: e.target.value })}
                    placeholder="mes"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Descripción</Label>
                <Textarea
                  value={editingPlan.description}
                  onChange={(e) => setEditingPlan({ ...editingPlan, description: e.target.value })}
                  placeholder="Descripción del plan..."
                  rows={3}
                />
              </div>

              <div className="space-y-2">
                <Label>Límite de Miembros</Label>
                <Input
                  value={editingPlan.maxMembers}
                  onChange={(e) => setEditingPlan({ ...editingPlan, maxMembers: e.target.value })}
                  placeholder="Hasta 500 miembros"
                />
              </div>

              <div className="space-y-2">
                <Label>Color del Plan</Label>
                <div className="grid grid-cols-3 gap-2">
                  {colorOptions.map((color) => (
                    <label 
                      key={color.value}
                      className={`flex items-center p-3 border rounded-lg cursor-pointer ${
                        editingPlan.color === color.value ? 'ring-2 ring-blue-500' : ''
                      }`}
                    >
                      <input
                        type="radio"
                        name="color"
                        value={color.value}
                        checked={editingPlan.color === color.value}
                        onChange={(e) => setEditingPlan({ ...editingPlan, color: e.target.value })}
                        className="sr-only"
                      />
                      <div className={`w-6 h-6 rounded-full ${color.preview} mr-2`}></div>
                      <span className="text-sm">{color.label}</span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex items-center space-x-2">
                <Switch
                  checked={editingPlan.popular}
                  onCheckedChange={(checked) => setEditingPlan({ ...editingPlan, popular: checked })}
                />
                <Label>Plan Popular</Label>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <Label>Características del Plan</Label>
                  <Button onClick={addFeature} variant="outline" size="sm">
                    <Plus className="h-4 w-4 mr-1" />
                    Agregar
                  </Button>
                </div>
                
                <div className="space-y-2">
                  {planFeatures.map((feature, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        value={feature}
                        onChange={(e) => updateFeature(index, e.target.value)}
                        placeholder="Característica del plan..."
                        className="flex-1"
                      />
                      <Button
                        onClick={() => removeFeature(index)}
                        variant="outline"
                        size="sm"
                        className="text-red-600"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-4">
                <Button 
                  onClick={() => setIsDialogOpen(false)} 
                  variant="outline"
                >
                  Cancelar
                </Button>
                <Button onClick={handleSavePlan}>
                  Guardar Plan
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
