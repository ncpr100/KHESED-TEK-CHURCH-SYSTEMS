
'use client'

import { useState } from 'react'
import { HexColorPicker } from 'react-colorful'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'

interface ColorPickerProps {
  label: string
  color: string
  onChange: (color: string) => void
  description?: string
}

export function ColorPicker({ label, color, onChange, description }: ColorPickerProps) {
  const [isOpen, setIsOpen] = useState(false)

  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {description && <p className="text-sm text-gray-600">{description}</p>}
      
      <div className="flex gap-3">
        <div 
          className="w-12 h-10 rounded border-2 border-gray-300 cursor-pointer shadow-sm"
          style={{ backgroundColor: color }}
          onClick={() => setIsOpen(!isOpen)}
        />
        <Input
          value={color}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1"
          placeholder="#000000"
        />
      </div>
      
      {isOpen && (
        <Card className="absolute z-50 mt-2">
          <CardContent className="p-4">
            <HexColorPicker color={color} onChange={onChange} />
            <div className="mt-3 flex justify-end">
              <button
                onClick={() => setIsOpen(false)}
                className="px-4 py-2 text-sm bg-gray-100 hover:bg-gray-200 rounded"
              >
                Done
              </button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
