
'use client'

import Link from 'next/link'
import { useSiteConfig } from '@/lib/config'
import { Mail, Phone, MapPin } from 'lucide-react'

export function MarketingFooter() {
  const { config } = useSiteConfig()

  return (
    <footer 
      className="py-12"
      style={{ backgroundColor: config.colors.primary }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-4">
              {config.logo ? (
                <div className="h-8 w-8 rounded-lg overflow-hidden bg-white p-1">
                  <img 
                    src={config.logo} 
                    alt={config.siteName} 
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div className="h-8 w-8 bg-white rounded-lg flex items-center justify-center">
                  <span 
                    className="font-bold"
                    style={{ color: config.colors.primary }}
                  >
                    {config.siteName.charAt(0)}
                  </span>
                </div>
              )}
              <div>
                <h3 
                  className="font-bold text-white"
                  style={{ fontFamily: config.fonts.heading }}
                >
                  {config.siteName}
                </h3>
                {config.tagline && (
                  <p 
                    className="text-xs text-white/80"
                    style={{ fontFamily: config.fonts.body }}
                  >
                    {config.tagline}
                  </p>
                )}
              </div>
            </div>
            <p 
              className="text-white/80 text-sm"
              style={{ fontFamily: config.fonts.body }}
            >
              {config.description}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 
              className="font-semibold text-white mb-4"
              style={{ fontFamily: config.fonts.heading }}
            >
              Enlaces Rápidos
            </h4>
            <ul className="space-y-2">
              <li>
                <Link 
                  href="/" 
                  className="text-white/80 hover:text-white transition-colors text-sm"
                  style={{ fontFamily: config.fonts.body }}
                >
                  Inicio
                </Link>
              </li>
              <li>
                <Link 
                  href="/features" 
                  className="text-white/80 hover:text-white transition-colors text-sm"
                  style={{ fontFamily: config.fonts.body }}
                >
                  Características
                </Link>
              </li>
              <li>
                <Link 
                  href="/contact" 
                  className="text-white/80 hover:text-white transition-colors text-sm"
                  style={{ fontFamily: config.fonts.body }}
                >
                  Contacto
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 
              className="font-semibold text-white mb-4"
              style={{ fontFamily: config.fonts.heading }}
            >
              Contacto
            </h4>
            <div className="space-y-2">
              <div className="flex items-center text-white/80 text-sm">
                <Mail className="h-4 w-4 mr-2" />
                <span style={{ fontFamily: config.fonts.body }}>
                  {config.contactEmail}
                </span>
              </div>
              <div className="flex items-center text-white/80 text-sm">
                <Phone className="h-4 w-4 mr-2" />
                <span style={{ fontFamily: config.fonts.body }}>
                  {config.phone}
                </span>
              </div>
              <div className="flex items-center text-white/80 text-sm">
                <MapPin className="h-4 w-4 mr-2" />
                <span style={{ fontFamily: config.fonts.body }}>
                  {config.address}
                </span>
              </div>
            </div>
          </div>
        </div>

        <div 
          className="mt-8 pt-8 border-t text-center text-white/80 text-sm"
          style={{ 
            borderColor: 'rgba(255,255,255,0.2)',
            fontFamily: config.fonts.body 
          }}
        >
          <p>© 2024 {config.siteName}. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
