
'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useSiteConfig } from '@/lib/config'
import Link from 'next/link'
import { 
  Users, 
  Calendar, 
  DollarSign, 
  MessageSquare, 
  BarChart3, 
  Shield,
  FileText,
  UserPlus,
  Bell,
  Globe,
  Database,
  Smartphone,
  ArrowRight
} from 'lucide-react'

export default function FeaturesPage() {
  const { config } = useSiteConfig()

  const featureCategories = [
    {
      title: 'Gestión de Miembros',
      description: 'Herramientas completas para administrar tu congregación',
      icon: Users,
      features: [
        { name: 'Base de datos de miembros', icon: Database },
        { name: 'Registro de nuevos miembros', icon: UserPlus },
        { name: 'Historial de participación', icon: FileText },
        { name: 'Grupos y ministerios', icon: Users },
        { name: 'Comunicación directa', icon: MessageSquare },
        { name: 'Reportes de membresía', icon: BarChart3 }
      ]
    },
    {
      title: 'Eventos y Actividades',
      description: 'Organiza y gestiona todos los eventos de tu iglesia',
      icon: Calendar,
      features: [
        { name: 'Calendario de eventos', icon: Calendar },
        { name: 'Registro de asistentes', icon: Users },
        { name: 'Recordatorios automáticos', icon: Bell },
        { name: 'Gestión de voluntarios', icon: UserPlus },
        { name: 'Recursos del evento', icon: FileText },
        { name: 'Reportes de asistencia', icon: BarChart3 }
      ]
    },
    {
      title: 'Donaciones y Finanzas',
      description: 'Control completo de las finanzas de tu iglesia',
      icon: DollarSign,
      features: [
        { name: 'Registro de donaciones', icon: DollarSign },
        { name: 'Donaciones en línea', icon: Globe },
        { name: 'Reportes financieros', icon: BarChart3 },
        { name: 'Seguimiento de diezmos', icon: FileText },
        { name: 'Recibos automáticos', icon: FileText },
        { name: 'Presupuestos y gastos', icon: Database }
      ]
    },
    {
      title: 'Comunicación',
      description: 'Mantente conectado con tu congregación',
      icon: MessageSquare,
      features: [
        { name: 'Mensajes masivos', icon: MessageSquare },
        { name: 'Notificaciones push', icon: Bell },
        { name: 'Boletines digitales', icon: FileText },
        { name: 'Redes sociales', icon: Globe },
        { name: 'App móvil', icon: Smartphone },
        { name: 'Portal de miembros', icon: Users }
      ]
    },
    {
      title: 'Reportes y Analytics',
      description: 'Insights valiosos para el crecimiento de tu iglesia',
      icon: BarChart3,
      features: [
        { name: 'Dashboard ejecutivo', icon: BarChart3 },
        { name: 'Análisis de crecimiento', icon: FileText },
        { name: 'Reportes de donaciones', icon: DollarSign },
        { name: 'Métricas de participación', icon: Users },
        { name: 'Reportes personalizados', icon: Database },
        { name: 'Exportación de datos', icon: FileText }
      ]
    },
    {
      title: 'Seguridad y Respaldo',
      description: 'Protección avanzada para los datos de tu iglesia',
      icon: Shield,
      features: [
        { name: 'Encriptación de datos', icon: Shield },
        { name: 'Respaldos automáticos', icon: Database },
        { name: 'Control de acceso', icon: Users },
        { name: 'Auditoría de cambios', icon: FileText },
        { name: 'Cumplimiento GDPR', icon: Shield },
        { name: 'Soporte 24/7', icon: Bell }
      ]
    }
  ]

  return (
    <div 
      className="min-h-screen"
      style={{ 
        backgroundColor: config.colors.background,
        color: config.colors.text,
        fontFamily: config.fonts.body 
      }}
    >
      {/* Hero Section */}
      <section className="gradient-hero hero-pattern py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 
            className="text-4xl sm:text-5xl font-bold text-white mb-6"
            style={{ fontFamily: config.fonts.heading }}
          >
            Características Completas para
            <span className="block text-yellow-300">Gestión de Iglesias</span>
          </h1>
          <p 
            className="text-xl text-blue-100 mb-8"
            style={{ fontFamily: config.fonts.body }}
          >
            Descubre todas las herramientas que {config.siteName} ofrece para 
            simplificar la administración y fortalecer la comunidad de tu iglesia.
          </p>
        </div>
      </section>

      {/* Features Categories */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-20">
            {featureCategories.map((category, categoryIndex) => {
              const CategoryIcon = category.icon
              return (
                <div key={categoryIndex}>
                  <div className="text-center mb-12">
                    <div 
                      className="w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center"
                      style={{ backgroundColor: config.colors.primary }}
                    >
                      <CategoryIcon className="h-8 w-8 text-white" />
                    </div>
                    <h2 
                      className="text-3xl sm:text-4xl font-bold mb-4"
                      style={{ 
                        color: config.colors.text,
                        fontFamily: config.fonts.heading 
                      }}
                    >
                      {category.title}
                    </h2>
                    <p 
                      className="text-xl text-gray-600 max-w-2xl mx-auto"
                      style={{ fontFamily: config.fonts.body }}
                    >
                      {category.description}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {category.features.map((feature, featureIndex) => {
                      const FeatureIcon = feature.icon
                      return (
                        <Card key={featureIndex} className="feature-card border-none shadow-lg">
                          <CardHeader className="pb-4">
                            <div className="flex items-center space-x-3">
                              <div 
                                className="w-10 h-10 rounded-lg flex items-center justify-center"
                                style={{ backgroundColor: `${config.colors.primary}20` }}
                              >
                                <FeatureIcon 
                                  className="h-5 w-5" 
                                  style={{ color: config.colors.primary }}
                                />
                              </div>
                              <CardTitle 
                                className="text-lg"
                                style={{ 
                                  color: config.colors.text,
                                  fontFamily: config.fonts.heading 
                                }}
                              >
                                {feature.name}
                              </CardTitle>
                            </div>
                          </CardHeader>
                        </Card>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Integration Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-3xl sm:text-4xl font-bold mb-4"
              style={{ 
                color: config.colors.text,
                fontFamily: config.fonts.heading 
              }}
            >
              Integración y Compatibilidad
            </h2>
            <p 
              className="text-xl text-gray-600 max-w-2xl mx-auto"
              style={{ fontFamily: config.fonts.body }}
            >
              {config.siteName} se integra perfectamente con las herramientas que ya usas
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { name: 'Redes Sociales', description: 'Facebook, Instagram, WhatsApp', icon: Globe },
              { name: 'Pagos Online', description: 'PayPal, Stripe, Transferencias', icon: DollarSign },
              { name: 'Apps Móviles', description: 'iOS y Android nativas', icon: Smartphone },
              { name: 'Herramientas Email', description: 'MailChimp, Gmail, Outlook', icon: MessageSquare }
            ].map((integration, index) => {
              const IntegrationIcon = integration.icon
              return (
                <Card key={index} className="border-none shadow-lg text-center">
                  <CardHeader>
                    <div 
                      className="w-12 h-12 rounded-full mx-auto mb-4 flex items-center justify-center"
                      style={{ backgroundColor: config.colors.primary }}
                    >
                      <IntegrationIcon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle 
                      className="text-lg mb-2"
                      style={{ 
                        color: config.colors.text,
                        fontFamily: config.fonts.heading 
                      }}
                    >
                      {integration.name}
                    </CardTitle>
                    <CardDescription 
                      style={{ fontFamily: config.fonts.body }}
                    >
                      {integration.description}
                    </CardDescription>
                  </CardHeader>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-hero hero-pattern">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 
            className="text-3xl sm:text-4xl font-bold text-white mb-6"
            style={{ fontFamily: config.fonts.heading }}
          >
            ¿Listo para ver {config.siteName} en acción?
          </h2>
          <p 
            className="text-xl text-blue-100 mb-8"
            style={{ fontFamily: config.fonts.body }}
          >
            Programa una demo personalizada y descubre cómo podemos transformar 
            la gestión de tu iglesia.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              asChild
              size="lg"
              className="bg-white font-semibold px-8 py-4 text-lg"
              style={{ 
                color: config.colors.primary,
                fontFamily: config.fonts.body 
              }}
            >
              <Link href="/contact">
                Solicitar Demo Gratuita
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <Button 
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white font-semibold px-8 py-4 text-lg hover:text-gray-900"
              style={{ fontFamily: config.fonts.body }}
            >
              <Link href="/">Volver al Inicio</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
