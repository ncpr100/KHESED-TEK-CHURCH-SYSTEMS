
'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { useSiteConfig } from '@/lib/config'
import { formatPrice } from '@/lib/utils'
import { 
  Check, 
  Star, 
  Users, 
  Zap, 
  Crown,
  Mail,
  Phone,
  MapPin,
  Clock,
  Send,
  CheckCircle,
  DollarSign
} from 'lucide-react'

export default function ContactPage() {
  const { config } = useSiteConfig()
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    church: '',
    phone: '',
    members: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    // Simulate form submission
    setTimeout(() => {
      setIsSubmitting(false)
      setSubmitted(true)
      setFormData({
        name: '',
        email: '',
        church: '',
        phone: '',
        members: '',
        message: ''
      })
    }, 2000)
  }

  const getPlanIcon = (planName: string) => {
    switch (planName.toLowerCase()) {
      case 'básico':
      case 'basic':
        return Users
      case 'profesional':
      case 'professional':
        return Zap
      case 'enterprise':
        return Crown
      default:
        return DollarSign
    }
  }

  return (
    <div 
      className="min-h-screen"
      style={{ 
        backgroundColor: config.colors.background,
        color: config.colors.text,
        fontFamily: config.fonts.body 
      }}
    >
      {/* Hero Section */}
      <section className="gradient-hero hero-pattern py-20">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 
            className="text-4xl sm:text-5xl font-bold text-white mb-6"
            style={{ fontFamily: config.fonts.heading }}
          >
            Precios Transparentes y
            <span className="block text-yellow-300">Demo Personalizada</span>
          </h1>
          <p 
            className="text-xl text-blue-100 mb-8"
            style={{ fontFamily: config.fonts.body }}
          >
            Elige el plan perfecto para tu iglesia y solicita una demo gratuita 
            personalizada con nuestro equipo de especialistas.
          </p>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-3xl sm:text-4xl font-bold mb-4"
              style={{ 
                color: config.colors.text,
                fontFamily: config.fonts.heading 
              }}
            >
              Planes Diseñados para Cada Iglesia
            </h2>
            <p 
              className="text-xl text-gray-600 mb-4"
              style={{ fontFamily: config.fonts.body }}
            >
              Sin tarifas ocultas, sin compromisos a largo plazo. Comienza con una demo gratuita.
            </p>
            <div className="flex items-center justify-center gap-2 text-blue-600">
              <span className="text-lg">🇺🇸</span>
              <span 
                className="font-medium"
                style={{ fontFamily: config.fonts.body }}
              >
                Precios en USD - Facturación manual por administrador
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {config.subscriptionPlans.map((plan, index) => {
              const IconComponent = getPlanIcon(plan.name)
              return (
                <Card 
                  key={plan.id} 
                  className={`relative border-none shadow-lg ${plan.popular ? 'ring-2 ring-purple-600 scale-105' : ''}`}
                >
                  {plan.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <div className="bg-purple-600 text-white px-4 py-1 rounded-full text-sm font-semibold flex items-center">
                        <Star className="h-4 w-4 mr-1" />
                        Más Popular
                      </div>
                    </div>
                  )}
                  
                  <CardHeader className="text-center pb-8 pt-8">
                    <div className={`w-16 h-16 bg-gradient-to-r ${plan.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle 
                      className="text-2xl mb-2"
                      style={{ 
                        color: config.colors.text,
                        fontFamily: config.fonts.heading 
                      }}
                    >
                      {plan.displayName || plan.name}
                    </CardTitle>
                    <div className="mb-2">
                      <span 
                        className="text-4xl font-bold"
                        style={{ 
                          color: config.colors.text,
                          fontFamily: config.fonts.heading 
                        }}
                      >
                        ${plan.price}.00
                      </span>
                      <span 
                        className="text-gray-600"
                        style={{ fontFamily: config.fonts.body }}
                      >
                        /{plan.period}
                      </span>
                    </div>
                    <div 
                      className="text-sm font-semibold text-blue-600 mb-2"
                      style={{ fontFamily: config.fonts.body }}
                    >
                      {plan.maxMembers}
                    </div>
                    <CardDescription 
                      className="text-gray-600"
                      style={{ fontFamily: config.fonts.body }}
                    >
                      {plan.description}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <ul className="space-y-3 mb-8">
                      {plan.features.map((feature, idx) => (
                        <li key={idx} className="flex items-start">
                          <Check className="h-5 w-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                          <span 
                            className="text-gray-700"
                            style={{ fontFamily: config.fonts.body }}
                          >
                            {feature}
                          </span>
                        </li>
                      ))}
                    </ul>
                    
                    <Button 
                      className={`w-full bg-gradient-to-r ${plan.color} hover:opacity-90 text-white`}
                      size="lg"
                      style={{ fontFamily: config.fonts.body }}
                    >
                      Solicitar Demo
                    </Button>
                  </CardContent>
                </Card>
              )
            })}
          </div>

          <div className="text-center mt-12">
            <p 
              className="text-gray-600 mb-4"
              style={{ fontFamily: config.fonts.body }}
            >
              ¿Necesitas un plan personalizado para tu organización?
            </p>
            <Button 
              variant="outline" 
              size="lg"
              style={{ fontFamily: config.fonts.body }}
            >
              Contactar Ventas
            </Button>
          </div>
        </div>
      </section>

      {/* Contact Form & Info */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div>
              <h2 
                className="text-3xl font-bold mb-6"
                style={{ 
                  color: config.colors.text,
                  fontFamily: config.fonts.heading 
                }}
              >
                Solicita tu Demo Gratuita
              </h2>
              <p 
                className="text-gray-600 mb-8"
                style={{ fontFamily: config.fonts.body }}
              >
                Completa el formulario y nuestro equipo se pondrá en contacto contigo 
                para programar una demostración personalizada de {config.siteName}.
              </p>

              {submitted ? (
                <Card className="border-green-200 bg-green-50">
                  <CardContent className="p-8 text-center">
                    <CheckCircle className="h-16 w-16 text-green-600 mx-auto mb-4" />
                    <h3 
                      className="text-xl font-semibold text-green-800 mb-2"
                      style={{ fontFamily: config.fonts.heading }}
                    >
                      ¡Solicitud Enviada!
                    </h3>
                    <p 
                      className="text-green-700"
                      style={{ fontFamily: config.fonts.body }}
                    >
                      Nuestro equipo se pondrá en contacto contigo dentro de las próximas 24 horas 
                      para programar tu demo personalizada.
                    </p>
                  </CardContent>
                </Card>
              ) : (
                <Card className="border-none shadow-lg">
                  <CardContent className="p-8">
                    <form onSubmit={handleSubmit} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="name" style={{ fontFamily: config.fonts.body }}>
                            Nombre completo *
                          </Label>
                          <Input
                            id="name"
                            name="name"
                            value={formData.name}
                            onChange={handleInputChange}
                            required
                            className="mt-1"
                            style={{ fontFamily: config.fonts.body }}
                          />
                        </div>
                        <div>
                          <Label htmlFor="email" style={{ fontFamily: config.fonts.body }}>
                            Email *
                          </Label>
                          <Input
                            id="email"
                            name="email"
                            type="email"
                            value={formData.email}
                            onChange={handleInputChange}
                            required
                            className="mt-1"
                            style={{ fontFamily: config.fonts.body }}
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                          <Label htmlFor="church" style={{ fontFamily: config.fonts.body }}>
                            Nombre de la iglesia *
                          </Label>
                          <Input
                            id="church"
                            name="church"
                            value={formData.church}
                            onChange={handleInputChange}
                            required
                            className="mt-1"
                            style={{ fontFamily: config.fonts.body }}
                          />
                        </div>
                        <div>
                          <Label htmlFor="phone" style={{ fontFamily: config.fonts.body }}>
                            Teléfono
                          </Label>
                          <Input
                            id="phone"
                            name="phone"
                            value={formData.phone}
                            onChange={handleInputChange}
                            className="mt-1"
                            style={{ fontFamily: config.fonts.body }}
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="members" style={{ fontFamily: config.fonts.body }}>
                          Número aproximado de miembros
                        </Label>
                        <Input
                          id="members"
                          name="members"
                          value={formData.members}
                          onChange={handleInputChange}
                          placeholder="Ej: 150"
                          className="mt-1"
                          style={{ fontFamily: config.fonts.body }}
                        />
                      </div>

                      <div>
                        <Label htmlFor="message" style={{ fontFamily: config.fonts.body }}>
                          Cuéntanos sobre tus necesidades específicas
                        </Label>
                        <Textarea
                          id="message"
                          name="message"
                          value={formData.message}
                          onChange={handleInputChange}
                          rows={4}
                          className="mt-1"
                          placeholder="Describe los desafíos actuales de gestión en tu iglesia o cualquier pregunta específica..."
                          style={{ fontFamily: config.fonts.body }}
                        />
                      </div>

                      <Button 
                        type="submit" 
                        disabled={isSubmitting}
                        className="w-full text-white"
                        style={{ 
                          backgroundColor: config.colors.primary,
                          fontFamily: config.fonts.body 
                        }}
                        size="lg"
                      >
                        {isSubmitting ? (
                          <div className="flex items-center">
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Enviando...
                          </div>
                        ) : (
                          <div className="flex items-center">
                            <Send className="h-5 w-5 mr-2" />
                            Solicitar Demo Gratuita
                          </div>
                        )}
                      </Button>
                    </form>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Contact Information */}
            <div>
              <h2 
                className="text-3xl font-bold mb-6"
                style={{ 
                  color: config.colors.text,
                  fontFamily: config.fonts.heading 
                }}
              >
                Información de Contacto
              </h2>
              <p 
                className="text-gray-600 mb-8"
                style={{ fontFamily: config.fonts.body }}
              >
                Nuestro equipo de especialistas está listo para ayudarte a encontrar 
                la mejor solución para tu iglesia.
              </p>

              <div className="space-y-6">
                <Card className="border-none shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: config.colors.primary }}
                      >
                        <Mail className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 
                          className="font-semibold mb-1"
                          style={{ 
                            color: config.colors.text,
                            fontFamily: config.fonts.heading 
                          }}
                        >
                          Email
                        </h3>
                        <p 
                          className="text-gray-600 mb-2"
                          style={{ fontFamily: config.fonts.body }}
                        >
                          {config.contactEmail}
                        </p>
                        <p 
                          className="text-sm text-gray-500"
                          style={{ fontFamily: config.fonts.body }}
                        >
                          Respuesta en menos de 24 horas
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: config.colors.secondary }}
                      >
                        <Phone className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 
                          className="font-semibold mb-1"
                          style={{ 
                            color: config.colors.text,
                            fontFamily: config.fonts.heading 
                          }}
                        >
                          WhatsApp
                        </h3>
                        <p 
                          className="text-gray-600 mb-2"
                          style={{ fontFamily: config.fonts.body }}
                        >
                          {config.phone}
                        </p>
                        <p 
                          className="text-sm text-gray-500"
                          style={{ fontFamily: config.fonts.body }}
                        >
                          Chat directo con nuestro equipo
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: config.colors.accent }}
                      >
                        <MapPin className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 
                          className="font-semibold mb-1"
                          style={{ 
                            color: config.colors.text,
                            fontFamily: config.fonts.heading 
                          }}
                        >
                          Ubicación
                        </h3>
                        <p 
                          className="text-gray-600 mb-2"
                          style={{ fontFamily: config.fonts.body }}
                        >
                          {config.address}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-none shadow-lg">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div 
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: 'orange' }}
                      >
                        <Clock className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 
                          className="font-semibold mb-1"
                          style={{ 
                            color: config.colors.text,
                            fontFamily: config.fonts.heading 
                          }}
                        >
                          Horarios
                        </h3>
                        <p 
                          className="text-gray-600 mb-2"
                          style={{ fontFamily: config.fonts.body }}
                        >
                          Lun-Vie 8AM-8PM
                        </p>
                        <p 
                          className="text-sm text-gray-500"
                          style={{ fontFamily: config.fonts.body }}
                        >
                          Horario de Colombia (COT)
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-3xl font-bold mb-4"
              style={{ 
                color: config.colors.text,
                fontFamily: config.fonts.heading 
              }}
            >
              Preguntas Frecuentes
            </h2>
          </div>

          <div className="space-y-8">
            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <h3 
                  className="text-xl font-semibold mb-3"
                  style={{ 
                    color: config.colors.text,
                    fontFamily: config.fonts.heading 
                  }}
                >
                  ¿Qué incluye la demo gratuita?
                </h3>
                <p 
                  className="text-gray-600"
                  style={{ fontFamily: config.fonts.body }}
                >
                  Nuestra demo personalizada incluye una presentación completa de todas las características, 
                  configuración de datos de prueba con información de tu iglesia, y una sesión de preguntas 
                  y respuestas con nuestro equipo de especialistas.
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <h3 
                  className="text-xl font-semibold mb-3"
                  style={{ 
                    color: config.colors.text,
                    fontFamily: config.fonts.heading 
                  }}
                >
                  ¿Puedo cambiar de plan después?
                </h3>
                <p 
                  className="text-gray-600"
                  style={{ fontFamily: config.fonts.body }}
                >
                  Absolutamente. Puedes actualizar o degradar tu plan en cualquier momento. 
                  Los cambios se reflejan en tu próxima factura y no hay penalizaciones por cambios.
                </p>
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg">
              <CardContent className="p-8">
                <h3 
                  className="text-xl font-semibold mb-3"
                  style={{ 
                    color: config.colors.text,
                    fontFamily: config.fonts.heading 
                  }}
                >
                  ¿Qué tipo de soporte técnico ofrecen?
                </h3>
                <p 
                  className="text-gray-600"
                  style={{ fontFamily: config.fonts.body }}
                >
                  Ofrecemos soporte técnico completo en español, incluyendo capacitación inicial, 
                  documentación detallada, chat en vivo, soporte por email y telefónico según tu plan.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  )
}
