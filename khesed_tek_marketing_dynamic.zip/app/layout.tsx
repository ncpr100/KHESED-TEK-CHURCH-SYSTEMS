
import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import { MarketingHeader } from '@/components/marketing/header'
import { MarketingFooter } from '@/components/marketing/footer'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Kḥesed-tek - Sistema de Gestión para Iglesias',
  description: 'La solución completa de gestión para iglesias modernas. Administra miembros, eventos, donaciones y más desde una sola plataforma.',
  keywords: 'gestión iglesia, software iglesia, administración iglesia, miembros iglesia, eventos iglesia, donaciones iglesia',
  authors: [{ name: 'Kḥesed-tek Systems' }],
  creator: 'Kḥesed-tek Systems',
  openGraph: {
    title: 'Kḥesed-tek - Sistema de Gestión para Iglesias',
    description: 'La solución completa de gestión para iglesias modernas. Administra miembros, eventos, donaciones y más desde una sola plataforma.',
    url: 'https://khesed-tek.com',
    siteName: 'Kḥesed-tek',
    images: [
      {
        url: '/og-image.jpg',
        width: 1200,
        height: 630,
        alt: 'Kḥesed-tek - Sistema de Gestión para Iglesias',
      },
    ],
    locale: 'es_ES',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Kḥesed-tek - Sistema de Gestión para Iglesias',
    description: 'La solución completa de gestión para iglesias modernas.',
    images: ['/og-image.jpg'],
  },
  robots: {
    index: true,
    follow: true,
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="es">
      <head>
        <link rel="icon" href="/favicon.ico" />
        <link rel="canonical" href="https://khesed-tek.com" />
      </head>
      <body className={inter.className}>
        <MarketingHeader />
        <main className="pt-20">
          {children}
        </main>
        <MarketingFooter />
      </body>
    </html>
  )
}
