
'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { useSiteConfig } from '@/lib/config'
import { 
  Users, 
  Calendar, 
  DollarSign, 
  MessageSquare, 
  BarChart3, 
  Shield,
  CheckCircle,
  ArrowRight,
  Star
} from 'lucide-react'

export default function LandingPage() {
  const { config } = useSiteConfig()

  const features = [
    {
      icon: Users,
      title: 'Gestión de Miembros',
      description: 'Administra la información de todos los miembros de tu congregación de manera sencilla y organizada.'
    },
    {
      icon: Calendar,
      title: 'Eventos y Actividades',
      description: 'Planifica, organiza y gestiona eventos, cultos y actividades especiales con facilidad.'
    },
    {
      icon: DollarSign,
      title: 'Control de Donaciones',
      description: 'Registra y administra todas las donaciones y ofrendas con reportes detallados.'
    },
    {
      icon: MessageSquare,
      title: 'Comunicación',
      description: 'Mantén comunicación efectiva con tu congregación a través de múltiples canales.'
    },
    {
      icon: BarChart3,
      title: 'Reportes y Analytics',
      description: 'Obtén insights valiosos sobre el crecimiento y la participación de tu iglesia.'
    },
    {
      icon: Shield,
      title: 'Seguridad y Respaldo',
      description: 'Datos protegidos con los más altos estándares de seguridad y respaldos automáticos.'
    }
  ]

  const benefits = [
    'Interfaz intuitiva y fácil de usar',
    'Acceso desde cualquier dispositivo',
    'Soporte técnico especializado',
    'Actualizaciones automáticas',
    'Integración con redes sociales',
    'Reportes personalizables'
  ]

  const testimonials = [
    {
      name: 'Pastor Carlos Ruiz',
      church: 'Iglesia Central',
      content: 'Kḥesed-tek ha revolucionado la manera en que administramos nuestra iglesia. Es increíblemente fácil de usar.',
      rating: 5
    },
    {
      name: 'María González',
      church: 'Iglesia Nueva Vida',
      content: 'La gestión de miembros nunca había sido tan sencilla. Recomendamos esta plataforma a todas las iglesias.',
      rating: 5
    }
  ]

  return (
    <div 
      className="min-h-screen"
      style={{ 
        backgroundColor: config.colors.background,
        color: config.colors.text,
        fontFamily: config.fonts.body 
      }}
    >
      {/* Hero Section */}
      <section className="gradient-hero hero-pattern py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 
            className="text-4xl sm:text-6xl font-bold text-white mb-6"
            style={{ fontFamily: config.fonts.heading }}
          >
            La Solución Completa para
            <span className="block text-yellow-300">Gestión de Iglesias</span>
          </h1>
          <p 
            className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto"
            style={{ fontFamily: config.fonts.body }}
          >
            {config.description}
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button 
              asChild
              size="lg"
              className="bg-white font-semibold px-8 py-4 text-lg"
              style={{ 
                color: config.colors.primary,
                fontFamily: config.fonts.body 
              }}
            >
              <Link href="/contact">Solicitar Demo Gratuita</Link>
            </Button>
            <Button 
              asChild
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white font-semibold px-8 py-4 text-lg hover:text-gray-900"
              style={{ fontFamily: config.fonts.body }}
            >
              <Link href="/features">Ver Características</Link>
            </Button>
          </div>
          <p 
            className="text-sm text-blue-200 mt-4"
            style={{ fontFamily: config.fonts.body }}
          >
            ✓ Demo sin compromiso  ✓ Configuración incluida  ✓ Soporte 24/7
          </p>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-3xl sm:text-4xl font-bold mb-4"
              style={{ 
                color: config.colors.text,
                fontFamily: config.fonts.heading 
              }}
            >
              Todo lo que necesitas para gestionar tu iglesia
            </h2>
            <p 
              className="text-xl text-gray-600 max-w-2xl mx-auto"
              style={{ fontFamily: config.fonts.body }}
            >
              Una plataforma integral que simplifica la administración y fortalece la conexión con tu comunidad.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const IconComponent = feature.icon
              return (
                <Card key={index} className="feature-card border-none shadow-lg">
                  <CardHeader className="text-center">
                    <div 
                      className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4"
                      style={{ backgroundColor: config.colors.primary }}
                    >
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <CardTitle 
                      className="text-xl mb-2"
                      style={{ 
                        color: config.colors.text,
                        fontFamily: config.fonts.heading 
                      }}
                    >
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="text-center">
                    <CardDescription 
                      className="text-gray-600"
                      style={{ fontFamily: config.fonts.body }}
                    >
                      {feature.description}
                    </CardDescription>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 
                className="text-3xl sm:text-4xl font-bold mb-6"
                style={{ 
                  color: config.colors.text,
                  fontFamily: config.fonts.heading 
                }}
              >
                ¿Por qué elegir {config.siteName}?
              </h2>
              <p 
                className="text-lg text-gray-600 mb-8"
                style={{ fontFamily: config.fonts.body }}
              >
                Más de 100 iglesias confían en nuestra plataforma para simplificar su administración 
                y enfocarse en lo que realmente importa: su ministerio.
              </p>
              
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="h-6 w-6 text-green-500 mr-3 flex-shrink-0" />
                    <span 
                      className="text-gray-700"
                      style={{ fontFamily: config.fonts.body }}
                    >
                      {benefit}
                    </span>
                  </div>
                ))}
              </div>

              <Button 
                asChild
                size="lg"
                className="mt-8 text-white"
                style={{ 
                  backgroundColor: config.colors.primary,
                  fontFamily: config.fonts.body 
                }}
              >
                <Link href="/features">
                  Explorar todas las características
                  <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </Button>
            </div>

            <div className="lg:pl-12">
              <div 
                className="rounded-2xl p-8"
                style={{ backgroundColor: `${config.colors.primary}10` }}
              >
                <div className="text-center">
                  <div 
                    className="text-6xl font-bold mb-2 gradient-text"
                    style={{ fontFamily: config.fonts.heading }}
                  >
                    100+
                  </div>
                  <p 
                    className="text-gray-600 mb-6"
                    style={{ fontFamily: config.fonts.body }}
                  >
                    Iglesias activas usando nuestra plataforma
                  </p>
                  
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div 
                        className="text-2xl font-bold"
                        style={{ 
                          color: config.colors.primary,
                          fontFamily: config.fonts.heading 
                        }}
                      >
                        50K+
                      </div>
                      <p 
                        className="text-sm text-gray-600"
                        style={{ fontFamily: config.fonts.body }}
                      >
                        Miembros registrados
                      </p>
                    </div>
                    <div>
                      <div 
                        className="text-2xl font-bold"
                        style={{ 
                          color: config.colors.secondary,
                          fontFamily: config.fonts.heading 
                        }}
                      >
                        1M+
                      </div>
                      <p 
                        className="text-sm text-gray-600"
                        style={{ fontFamily: config.fonts.body }}
                      >
                        Eventos organizados
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 
              className="text-3xl sm:text-4xl font-bold mb-4"
              style={{ 
                color: config.colors.text,
                fontFamily: config.fonts.heading 
              }}
            >
              Lo que dicen nuestros clientes
            </h2>
            <p 
              className="text-xl text-gray-600"
              style={{ fontFamily: config.fonts.body }}
            >
              Testimonios reales de pastores y administradores que transformaron su gestión.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="border-none shadow-lg">
                <CardContent className="p-8">
                  <div className="flex mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-5 w-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p 
                    className="text-gray-700 mb-6 italic"
                    style={{ fontFamily: config.fonts.body }}
                  >
                    "{testimonial.content}"
                  </p>
                  <div>
                    <div 
                      className="font-semibold"
                      style={{ 
                        color: config.colors.text,
                        fontFamily: config.fonts.heading 
                      }}
                    >
                      {testimonial.name}
                    </div>
                    <div 
                      className="text-gray-600"
                      style={{ fontFamily: config.fonts.body }}
                    >
                      {testimonial.church}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-hero hero-pattern">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 
            className="text-3xl sm:text-4xl font-bold text-white mb-6"
            style={{ fontFamily: config.fonts.heading }}
          >
            ¿Listo para transformar la gestión de tu iglesia?
          </h2>
          <p 
            className="text-xl text-blue-100 mb-8"
            style={{ fontFamily: config.fonts.body }}
          >
            Únete a más de 100 iglesias que ya están utilizando {config.siteName} para 
            simplificar su administración y fortalecer su ministerio.
          </p>
          <Button 
            asChild
            size="lg"
            className="bg-white font-semibold px-8 py-4 text-lg"
            style={{ 
              color: config.colors.primary,
              fontFamily: config.fonts.body 
            }}
          >
            <Link href="/contact">Comenzar Demo Gratuita</Link>
          </Button>
          <p 
            className="text-sm text-blue-200 mt-4"
            style={{ fontFamily: config.fonts.body }}
          >
            Sin tarjeta de crédito • Configuración gratuita • Soporte incluido
          </p>
        </div>
      </section>
    </div>
  )
}
