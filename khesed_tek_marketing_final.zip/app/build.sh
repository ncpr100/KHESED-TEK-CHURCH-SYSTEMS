#!/bin/bash
export __NEXT_TEST_MODE=1
export NEXT_DIST_DIR=.build
yarn run build:original
echo exit_code=$?
