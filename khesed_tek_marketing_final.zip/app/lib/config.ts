
import { useState, useEffect } from 'react'

export interface SiteConfig {
  id: string
  siteName: string
  tagline: string
  description: string
  contactEmail: string
  phone: string
  address: string
  colors: {
    primary: string
    secondary: string
    accent: string
    background: string
    text: string
  }
  fonts: {
    heading: string
    body: string
  }
  logo?: string
  favicon?: string
  subscriptionPlans: SubscriptionPlan[]
}

export interface SubscriptionPlan {
  id: string
  name: string
  displayName: string
  price: number
  period: string
  description: string
  maxMembers: string
  features: string[]
  popular: boolean
  color: string
}

export const defaultSiteConfig: SiteConfig = {
  id: '1',
  siteName: 'Kḥesed-tek',
  tagline: 'Church Management Systems',
  description: 'La solución completa de gestión para iglesias modernas.',
  contactEmail: 'SOPORTE@KHESED-TEK.COM',
  phone: '+57 302 123 4410',
  address: 'Barranquilla, Atlántico, Colombia',
  colors: {
    primary: '#1e293b',
    secondary: '#334155',
    accent: '#475569',
    background: '#ffffff',
    text: '#1e293b'
  },
  fonts: {
    heading: 'Inter',
    body: 'Inter'
  },
  subscriptionPlans: [
    {
      id: '1',
      name: 'Básico',
      displayName: 'Plan Básico',
      price: 149,
      period: 'mes',
      description: 'Perfecto para iglesias pequeñas que necesitan funcionalidades esenciales',
      maxMembers: 'Hasta 500 miembros',
      features: [
        'Gestión básica de miembros',
        'Calendario de eventos',
        'Registro de donaciones',
        'Comunicaciones básicas',
        'Reportes estándar',
        'Soporte por email'
      ],
      popular: false,
      color: 'from-blue-600 to-blue-700'
    },
    {
      id: '2',
      name: 'Profesional',
      displayName: 'Plan Profesional',
      price: 299,
      period: 'mes',
      description: 'Para iglesias medianas con necesidades avanzadas de gestión',
      maxMembers: 'Hasta 1000 miembros',
      features: [
        'Todo lo del plan Básico',
        'Gestión avanzada de voluntarios',
        'Biblioteca de sermones',
        'Solicitudes de oración',
        'Redes sociales integradas',
        'Analytics avanzados',
        'Constructor de sitios web',
        'Soporte telefónico'
      ],
      popular: true,
      color: 'from-purple-600 to-purple-700'
    },
    {
      id: '3',
      name: 'Enterprise',
      displayName: 'Plan Enterprise',
      price: 599,
      period: 'mes',
      description: 'Solución completa para organizaciones grandes y redes de iglesias',
      maxMembers: 'Hasta 5000 miembros',
      features: [
        'Todo lo del plan Profesional',
        'Multi-campus y sucursales',
        'API personalizada',
        'Integraciones específicas',
        'Capacitación personalizada',
        'Gestor de cuenta dedicado',
        'Soporte 24/7 prioritario',
        'Respaldos personalizados'
      ],
      popular: false,
      color: 'from-green-600 to-green-700'
    }
  ]
}

export const useSiteConfig = () => {
  const [config, setConfig] = useState<SiteConfig>(defaultSiteConfig)
  const [loading, setLoading] = useState(false)

  // In a real app, this would fetch from an API or local storage
  useEffect(() => {
    const savedConfig = localStorage?.getItem('siteConfig')
    if (savedConfig) {
      try {
        setConfig(JSON.parse(savedConfig))
      } catch (error) {
        console.error('Error parsing saved config:', error)
      }
    }
  }, [])

  const updateConfig = (newConfig: Partial<SiteConfig>) => {
    const updatedConfig = { ...config, ...newConfig }
    setConfig(updatedConfig)
    localStorage?.setItem('siteConfig', JSON.stringify(updatedConfig))
  }

  return {
    config,
    updateConfig,
    loading,
    setLoading
  }
}
