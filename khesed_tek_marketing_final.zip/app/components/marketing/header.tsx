
'use client'

import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Menu, X, Settings } from 'lucide-react'
import { useState } from 'react'
import { useSiteConfig } from '@/lib/config'
import { SiteEditor } from '@/components/admin/site-editor'
import { Dialog, DialogContent } from '@/components/ui/dialog'

export function MarketingHeader() {
  const { config } = useSiteConfig()
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isEditorOpen, setIsEditorOpen] = useState(false)

  const navigation = [
    { name: 'Inicio', href: '/' },
    { name: 'Características', href: '/features' },
    { name: 'Contacto', href: '/contact' },
  ]

  const dynamicStyles = {
    '--primary-color': config.colors.primary,
    '--secondary-color': config.colors.secondary,
    '--accent-color': config.colors.accent,
    '--background-color': config.colors.background,
    '--text-color': config.colors.text,
    '--heading-font': config.fonts.heading,
    '--body-font': config.fonts.body
  } as React.CSSProperties

  return (
    <>
      <style jsx global>{`
        :root {
          --primary-color: ${config.colors.primary};
          --secondary-color: ${config.colors.secondary};
          --accent-color: ${config.colors.accent};
          --background-color: ${config.colors.background};
          --text-color: ${config.colors.text};
          --heading-font: ${config.fonts.heading};
          --body-font: ${config.fonts.body};
        }
      `}</style>
      
      <header className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-sm border-b">
        <nav className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <Link href="/" className="flex items-center space-x-3">
              {config.logo ? (
                <div className="h-8 w-8 rounded-lg overflow-hidden">
                  <img 
                    src={config.logo} 
                    alt={config.siteName} 
                    className="w-full h-full object-cover"
                  />
                </div>
              ) : (
                <div 
                  className="h-8 w-8 rounded-lg flex items-center justify-center text-white font-bold"
                  style={{ backgroundColor: config.colors.primary }}
                >
                  <span>{config.siteName.charAt(0)}</span>
                </div>
              )}
              <div>
                <span 
                  className="text-xl font-bold"
                  style={{ 
                    color: config.colors.text,
                    fontFamily: config.fonts.heading 
                  }}
                >
                  {config.siteName}
                </span>
                {config.tagline && (
                  <p 
                    className="text-xs -mt-1"
                    style={{ color: config.colors.secondary }}
                  >
                    {config.tagline}
                  </p>
                )}
              </div>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  href={item.href}
                  className="hover:opacity-75 transition-opacity duration-200"
                  style={{ 
                    color: config.colors.text,
                    fontFamily: config.fonts.body 
                  }}
                >
                  {item.name}
                </Link>
              ))}
            </div>

            {/* CTA Button & Admin */}
            <div className="hidden md:flex items-center gap-2">
              <Button 
                asChild
                className="text-white"
                style={{ 
                  backgroundColor: config.colors.primary,
                  fontFamily: config.fonts.body 
                }}
              >
                <Link href="/contact">Solicitar Demo</Link>
              </Button>
              
              <Button 
                onClick={() => setIsEditorOpen(true)}
                variant="outline"
                size="sm"
              >
                <Settings className="h-4 w-4" />
              </Button>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden flex items-center gap-2">
              <Button 
                onClick={() => setIsEditorOpen(true)}
                variant="outline"
                size="sm"
              >
                <Settings className="h-4 w-4" />
              </Button>
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>

          {/* Mobile menu */}
          {isMenuOpen && (
            <div className="md:hidden">
              <div className="px-2 pt-2 pb-3 space-y-1 bg-white border-t">
                {navigation.map((item) => (
                  <Link
                    key={item.name}
                    href={item.href}
                    className="block px-3 py-2 transition-colors duration-200"
                    style={{ 
                      color: config.colors.text,
                      fontFamily: config.fonts.body 
                    }}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    {item.name}
                  </Link>
                ))}
                <div className="px-3 py-2">
                  <Button 
                    asChild
                    className="w-full text-white"
                    style={{ 
                      backgroundColor: config.colors.primary,
                      fontFamily: config.fonts.body 
                    }}
                    onClick={() => setIsMenuOpen(false)}
                  >
                    <Link href="/contact">Solicitar Demo</Link>
                  </Button>
                </div>
              </div>
            </div>
          )}
        </nav>
      </header>

      {/* Admin Editor Dialog */}
      <Dialog open={isEditorOpen} onOpenChange={setIsEditorOpen}>
        <DialogContent className="max-w-6xl max-h-[90vh] overflow-y-auto">
          <SiteEditor onClose={() => setIsEditorOpen(false)} />
        </DialogContent>
      </Dialog>
    </>
  )
}
